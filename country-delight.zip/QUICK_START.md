# Quick Start Guide - Country Delight Backend

## 🚀 Setup & Run

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up Environment
Create `.env` file:
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/country-delight
JWT_ACCESS_SECRET=your-super-secret-access-key-change-this-in-production
JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-this-in-production
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d
CORS_ORIGIN=*
```

### 3. Start MongoDB
```bash
# Windows
mongod

# Mac/Linux
sudo systemctl start mongod
```

### 4. Run the Application
```bash
npm run start:dev
```

### 5. Access Swagger Documentation
```
http://localhost:3000/api/docs
```

## 📦 Generate Postman Collection

```bash
# Make sure server is running first
node generate-postman.js
```

Then import `postman-collection.json` into Postman.

## 🗄️ Create First Admin User

Connect to MongoDB and run:

```javascript
use country-delight

db.users.insertOne({
  phone: "9999999999",
  email: "admin@countrydelight.com",
  password: "$2b$10$rqEpjyZ9vqxG8OqGkJ1jMuHvZ9eF2X7wGvZkqXJ.YvJZ9eF2X7wGv", // password: admin123
  firstName: "Admin",
  lastName: "User",
  role: "admin",
  isActive: true,
  isPhoneVerified: true,
  isEmailVerified: true,
  createdAt: new Date(),
  updatedAt: new Date()
})
```

## 🧪 Test the APIs

### 1. Admin Login
```
POST http://localhost:3000/api/v1/admin/login
{
  "email": "admin@countrydelight.com",
  "password": "admin123"
}
```

### 2. Create Category (Use admin token)
```
POST http://localhost:3000/api/v1/categories
Authorization: Bearer <admin_token>
{
  "name": "Milk",
  "description": "Fresh milk products",
  "isActive": true
}
```

### 3. Create Product
```
POST http://localhost:3000/api/v1/products
Authorization: Bearer <admin_token>
{
  "name": "Full Cream Milk",
  "description": "Fresh full cream milk",
  "category": "<category_id>",
  "price": 65,
  "discountedPrice": 60,
  "unit": "1L",
  "stockQuantity": 100
}
```

### 4. Create Subscription Plan
```
POST http://localhost:3000/api/v1/subscriptions/plans
Authorization: Bearer <admin_token>
{
  "name": "Daily Milk - 1L",
  "description": "Daily delivery of 1L milk",
  "product": "<product_id>",
  "type": "daily",
  "quantity": 1,
  "pricePerUnit": 60,
  "totalPrice": 1800,
  "duration": 30
}
```

### 5. Customer Signup (OTP)
```
POST http://localhost:3000/api/v1/auth/request-otp
{
  "phone": "9876543210"
}

POST http://localhost:3000/api/v1/auth/verify-otp
{
  "phone": "9876543210",
  "otp": "<otp_from_console>",
  "firstName": "John",
  "lastName": "Doe"
}
```

## 📚 Complete API List

### Authentication
- POST /auth/request-otp
- POST /auth/verify-otp
- POST /auth/login
- POST /auth/delivery-boy/request-otp
- POST /auth/delivery-boy/verify-otp
- POST /auth/refresh
- POST /auth/logout

### Admin
- POST /admin/login
- POST /admin/delivery-boy
- GET /admin/delivery-boys
- GET /admin/customers
- GET /admin/users

### Categories
- GET /categories
- POST /categories
- GET /categories/:id
- PATCH /categories/:id
- DELETE /categories/:id

### Products
- GET /products
- POST /products
- GET /products/:id
- PATCH /products/:id
- DELETE /products/:id

### Subscription Plans
- GET /subscriptions/plans
- POST /subscriptions/plans
- GET /subscriptions/plans/:id
- PATCH /subscriptions/plans/:id
- DELETE /subscriptions/plans/:id

### User Subscriptions
- POST /subscriptions
- GET /subscriptions/my-subscriptions
- PATCH /subscriptions/:id/pause
- PATCH /subscriptions/:id/resume
- PATCH /subscriptions/:id/cancel

### Addresses
- POST /addresses
- GET /addresses
- GET /addresses/:id
- PATCH /addresses/:id
- DELETE /addresses/:id

### Cart
- POST /cart
- GET /cart
- PATCH /cart/:productId
- DELETE /cart/:productId
- DELETE /cart

### Orders
- POST /orders
- GET /orders/my-orders
- GET /orders/:id
- PATCH /orders/:id/cancel
- GET /orders (Admin)
- PATCH /orders/:id/status (Admin)
- PATCH /orders/:id/assign (Admin)

### Delivery
- GET /delivery/my-deliveries
- GET /delivery/my-deliveries/:id
- PATCH /delivery/:id/status
- PATCH /delivery/:id/deliver
- GET /delivery/history

## 📂 Project Structure

```
src/
├── main.ts
├── app.module.ts
├── common/
│   ├── decorators/
│   ├── guards/
│   ├── enums/
│   └── interfaces/
├── database/
├── auth/
├── users/
├── admin/
├── otp/
├── tokens/
├── categories/
├── products/
├── subscriptions/
├── addresses/
├── cart/
├── orders/
└── delivery/
```

## 🔑 Key Features

1. ✅ Multi-role authentication (Customer, Delivery Boy, Admin)
2. ✅ OTP-based signup/login
3. ✅ JWT with refresh tokens
4. ✅ Product catalog with categories
5. ✅ Subscription plans (Daily, Weekly, Custom)
6. ✅ User subscriptions management
7. ✅ Shopping cart
8. ✅ Order management
9. ✅ Delivery boy operations
10. ✅ Complete Swagger documentation

## 📖 Documentation Files

- `README.md` - Main documentation
- `CLAUDE.md` - Architecture guide for AI assistance
- `COMPLETE_API_SUMMARY.md` - Complete API overview
- `IMPLEMENTATION_GUIDE.md` - Module implementation details
- `QUICK_START.md` - This file

## 🆘 Troubleshooting

### Server won't start
- Check if MongoDB is running
- Verify .env file exists and has correct values
- Run `npm install` to ensure dependencies are installed

### Cannot connect to MongoDB
- Start MongoDB: `mongod`
- Check connection string in .env
- Ensure MongoDB is running on default port 27017

### Swagger not loading
- Check server is running
- Navigate to exact URL: http://localhost:3000/api/docs
- Check console for errors

## 🎯 Next Steps

1. ✅ Basic setup complete
2. Create sample data (categories, products, plans)
3. Test all API endpoints
4. Integrate payment gateway
5. Add SMS service for OTPs
6. Deploy to production

## 📞 Support

Check documentation files for detailed information:
- Swagger: http://localhost:3000/api/docs
- API Summary: COMPLETE_API_SUMMARY.md
- Implementation: IMPLEMENTATION_GUIDE.md
