# Country Delight Clone Backend

A production-ready backend API for a Country Delight-style milk & grocery delivery application built with NestJS and MongoDB.

## Features

- **Multi-Role Authentication System**
  - Customer authentication via OTP
  - Delivery Boy authentication via OTP/Password
  - Admin authentication via Email/Password

- **JWT-Based Security**
  - Access tokens (15 minutes expiry)
  - Refresh tokens (7 days expiry)
  - Role-based access control (RBAC)

- **OTP System**
  - 6-digit OTP generation
  - 10-minute expiry
  - Maximum 5 verification attempts

- **User Management**
  - User profiles
  - Address management
  - Phone and email verification

## Tech Stack

- **Framework**: NestJS (TypeScript)
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (Access + Refresh tokens)
- **Validation**: class-validator, class-transformer
- **Password Hashing**: bcrypt
- **Configuration**: @nestjs/config

## Project Structure

```
src/
├── main.ts                 # Application entry point
├── app.module.ts          # Root module
├── common/                # Shared utilities
│   ├── decorators/        # Custom decorators (@CurrentUser, @Roles, @Public)
│   ├── guards/            # Auth guards (JwtAuthGuard, RolesGuard)
│   ├── enums/             # Enums (UserRole)
│   └── interfaces/        # Interfaces (JwtPayload)
├── config/                # Configuration
├── database/              # Database module
├── auth/                  # Authentication module
│   ├── dto/               # Data transfer objects
│   ├── strategies/        # Passport strategies
│   ├── auth.controller.ts
│   ├── auth.service.ts
│   └── auth.module.ts
├── users/                 # Users module
│   ├── schemas/           # Mongoose schemas
│   ├── dto/               # Data transfer objects
│   ├── users.controller.ts
│   ├── users.service.ts
│   └── users.module.ts
├── otp/                   # OTP module
│   ├── schemas/
│   ├── otp.service.ts
│   └── otp.module.ts
├── tokens/                # JWT tokens module
│   ├── tokens.service.ts
│   └── tokens.module.ts
└── admin/                 # Admin module
    ├── dto/
    ├── admin.controller.ts
    ├── admin.service.ts
    └── admin.module.ts
```

## Installation

1. **Clone the repository**
```bash
cd country-delight
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/country-delight
JWT_ACCESS_SECRET=your-access-secret
JWT_REFRESH_SECRET=your-refresh-secret
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d
```

4. **Start MongoDB**
```bash
# Make sure MongoDB is running
mongod
```

5. **Run the application**
```bash
# Development mode
npm run start:dev

# Production mode
npm run build
npm run start:prod
```

The API will be available at `http://localhost:3000/api/v1`

## API Documentation

### Base URL
```
http://localhost:3000/api/v1
```

---

### Authentication APIs

#### 1. Request OTP (Customer)
Send OTP to customer's phone for signup/login.

**Endpoint:** `POST /auth/request-otp`

**Request Body:**
```json
{
  "phone": "9876543210"
}
```

**Response:**
```json
{
  "message": "OTP sent successfully",
  "phone": "9876543210",
  "otp": "123456"
}
```

---

#### 2. Verify OTP & Signup (Customer)
Verify OTP and create/login customer account.

**Endpoint:** `POST /auth/verify-otp`

**Request Body:**
```json
{
  "phone": "9876543210",
  "otp": "123456",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:**
```json
{
  "user": {
    "id": "65abc123...",
    "phone": "9876543210",
    "email": null,
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 3. Login (Customer/Delivery Boy)
Login with phone/email and password.

**Endpoint:** `POST /auth/login`

**Request Body:**
```json
{
  "phone": "9876543210",
  "password": "password123"
}
```

OR

```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "user": {
    "id": "65abc123...",
    "phone": "9876543210",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 4. Refresh Token
Get new access token using refresh token.

**Endpoint:** `POST /auth/refresh`

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 5. Request OTP (Delivery Boy)
Delivery boy requests OTP for login. Note: Delivery boy must be created by admin first.

**Endpoint:** `POST /auth/delivery-boy/request-otp`

**Request Body:**
```json
{
  "phone": "9123456789"
}
```

**Response:**
```json
{
  "message": "OTP sent successfully",
  "phone": "9123456789",
  "otp": "123456"
}
```

**Note**: If phone number is not registered as delivery boy or account is inactive, you'll receive an error.

---

#### 6. Verify OTP & Login (Delivery Boy)
Delivery boy verifies OTP and logs in.

**Endpoint:** `POST /auth/delivery-boy/verify-otp`

**Request Body:**
```json
{
  "phone": "9123456789",
  "otp": "123456"
}
```

**Response:**
```json
{
  "user": {
    "id": "65abc456...",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 7. Refresh Token
Get new access token using refresh token.

**Endpoint:** `POST /auth/refresh`

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 8. Logout
Logout user and invalidate refresh token.

**Endpoint:** `POST /auth/logout`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:**
```json
{
  "message": "Logged out successfully"
}
```

---

### Admin APIs

#### 9. Admin Login
Admin login with email and password.

**Endpoint:** `POST /admin/login`

**Request Body:**
```json
{
  "email": "admin@countrydelight.com",
  "password": "admin123"
}
```

**Response:**
```json
{
  "user": {
    "id": "65abc123...",
    "phone": "9876543210",
    "email": "admin@countrydelight.com",
    "firstName": "Admin",
    "lastName": "User",
    "role": "admin"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

#### 10. Create Delivery Boy
Admin creates a delivery boy account.

**Endpoint:** `POST /admin/delivery-boy`

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "phone": "9123456789",
  "email": "delivery@example.com",
  "password": "delivery123",
  "firstName": "Delivery",
  "lastName": "Boy"
}
```

**Response:**
```json
{
  "message": "Delivery boy created successfully",
  "deliveryBoy": {
    "id": "65abc456...",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy"
  }
}
```

---

#### 11. Get All Delivery Boys
Admin gets list of all delivery boys.

**Endpoint:** `GET /admin/delivery-boys`

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:**
```json
[
  {
    "id": "65abc456...",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy",
    "isActive": true
  }
]
```

---

#### 12. Get All Customers
Admin gets list of all customers.

**Endpoint:** `GET /admin/customers`

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

---

#### 13. Get All Users
Admin gets list of all users.

**Endpoint:** `GET /admin/users`

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

---

### User Profile APIs

#### 14. Get Profile
Get current user's profile.

**Endpoint:** `GET /users/profile`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:**
```json
{
  "id": "65abc123...",
  "phone": "9876543210",
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "customer",
  "isActive": true,
  "isPhoneVerified": true,
  "address": {
    "street": "123 Main St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001"
  }
}
```

---

#### 15. Update Profile
Update current user's profile.

**Endpoint:** `PATCH /users/profile`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "newemail@example.com",
  "address": {
    "street": "456 New St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400002"
  }
}
```

---

## User Roles

- **ADMIN**: Full system access, can create delivery boys, view all users
- **CUSTOMER**: Can order products, manage profile
- **DELIVERY_BOY**: Can view assigned deliveries

## Security Features

- Passwords hashed with bcrypt (10 salt rounds)
- Refresh tokens hashed before storage
- JWT tokens with expiry
- Global validation pipes
- Role-based access control
- Phone number validation (Indian mobile numbers)

## Development

### Run in Development Mode
```bash
npm run start:dev
```

### Build for Production
```bash
npm run build
```

### Run Tests
```bash
npm test
```

### Lint Code
```bash
npm run lint
```

### Format Code
```bash
npm run format
```

## Creating First Admin User

After starting the application, you need to manually create the first admin user in MongoDB:

```javascript
// Connect to MongoDB
use country-delight

// Create admin user
db.users.insertOne({
  phone: "9999999999",
  email: "admin@countrydelight.com",
  password: "$2b$10$YourHashedPasswordHere", // Use bcrypt to hash
  firstName: "Admin",
  role: "admin",
  isActive: true,
  isPhoneVerified: true,
  isEmailVerified: true,
  createdAt: new Date(),
  updatedAt: new Date()
})
```

Or use the following Node.js script:

```javascript
const bcrypt = require('bcrypt');

async function generateAdminPassword() {
  const password = 'admin123';
  const hash = await bcrypt.hash(password, 10);
  console.log('Hashed password:', hash);
}

generateAdminPassword();
```

## Production Deployment

1. Set `NODE_ENV=production`
2. Use strong JWT secrets
3. Enable MongoDB authentication
4. Set up proper CORS origins
5. Integrate SMS service for OTP (Twilio, AWS SNS, etc.)
6. Enable rate limiting
7. Set up logging and monitoring
8. Use HTTPS

## SMS Integration (Production)

To integrate real SMS service, update `src/otp/otp.service.ts`:

```typescript
// Replace console.log with actual SMS service
async generateAndSave(phone: string): Promise<string> {
  // ... existing code ...

  // Send OTP via SMS service
  await this.smsService.send({
    to: phone,
    message: `Your Country Delight OTP is: ${otp}. Valid for 10 minutes.`
  });

  return 'OTP sent successfully'; // Don't return actual OTP
}
```

## License

MIT

## Support

For issues or questions, please open an issue in the repository.
