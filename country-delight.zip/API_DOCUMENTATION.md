# Country Delight API - Complete Documentation

## Table of Contents
- [Overview](#overview)
- [Authentication](#authentication)
- [Base URL](#base-url)
- [Authentication APIs](#authentication-apis)
- [Admin APIs](#admin-apis)
- [User Profile APIs](#user-profile-apis)
- [Category APIs](#category-apis)
- [Product APIs](#product-apis)
- [Subscription Plan APIs](#subscription-plan-apis)
- [User Subscription APIs](#user-subscription-apis)
- [Address APIs](#address-apis)
- [Cart APIs](#cart-apis)
- [Order APIs](#order-apis)
- [Delivery APIs](#delivery-apis)
- [Error Responses](#error-responses)
- [Status Codes](#status-codes)

---

## Overview

Country Delight API is a RESTful API for a milk and grocery delivery platform. It supports three user roles:
- **Customer**: Can browse products, subscribe to plans, place orders
- **Delivery Boy**: Can manage assigned deliveries
- **Admin**: Full system access

## Authentication

Most endpoints require JWT authentication. Include the access token in the Authorization header:

```
Authorization: Bearer <your_access_token>
```

Public endpoints don't require authentication.

## Base URL

```
http://localhost:3000/api/v1
```

---

# Authentication APIs

## 1. Request OTP (Customer)

Send OTP to customer's phone for signup/login.

**Endpoint:** `POST /auth/request-otp`

**Access:** Public

**Request Body:**
```json
{
  "phone": "9876543210"
}
```

**Response:** `200 OK`
```json
{
  "message": "OTP sent successfully",
  "phone": "9876543210",
  "otp": "123456"
}
```

**Notes:**
- OTP is valid for 10 minutes
- Maximum 5 verification attempts
- In production, OTP should not be returned in response

---

## 2. Verify OTP & Signup (Customer)

Verify OTP and create/login customer account.

**Endpoint:** `POST /auth/verify-otp`

**Access:** Public

**Request Body:**
```json
{
  "phone": "9876543210",
  "otp": "123456",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:** `200 OK`
```json
{
  "user": {
    "id": "65abc123def456789012345",
    "phone": "9876543210",
    "email": null,
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Notes:**
- Auto-creates account if user doesn't exist
- Returns JWT tokens for authentication

---

## 3. Login (Password-based)

Login with phone/email and password.

**Endpoint:** `POST /auth/login`

**Access:** Public

**Request Body (Phone):**
```json
{
  "phone": "9876543210",
  "password": "password123"
}
```

**Request Body (Email):**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:** `200 OK`
```json
{
  "user": {
    "id": "65abc123def456789012345",
    "phone": "9876543210",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Response:** `401 Unauthorized`
```json
{
  "statusCode": 401,
  "message": "Invalid credentials"
}
```

---

## 4. Request OTP (Delivery Boy)

Delivery boy requests OTP for login.

**Endpoint:** `POST /auth/delivery-boy/request-otp`

**Access:** Public

**Request Body:**
```json
{
  "phone": "9123456789"
}
```

**Response:** `200 OK`
```json
{
  "message": "OTP sent successfully",
  "phone": "9123456789",
  "otp": "123456"
}
```

**Error Response:** `401 Unauthorized`
```json
{
  "statusCode": 401,
  "message": "Delivery boy not found. Contact admin."
}
```

**Notes:**
- Delivery boy must be created by admin first
- Validates that user exists, is a delivery boy, and account is active

---

## 5. Verify OTP & Login (Delivery Boy)

Delivery boy verifies OTP and logs in.

**Endpoint:** `POST /auth/delivery-boy/verify-otp`

**Access:** Public

**Request Body:**
```json
{
  "phone": "9123456789",
  "otp": "123456"
}
```

**Response:** `200 OK`
```json
{
  "user": {
    "id": "65abc456def789012345678",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

## 6. Refresh Token

Get new access token using refresh token.

**Endpoint:** `POST /auth/refresh`

**Access:** Public

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response:** `200 OK`
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Notes:**
- Old refresh token is invalidated
- New token pair is issued

---

## 7. Logout

Logout user and invalidate refresh token.

**Endpoint:** `POST /auth/logout`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "message": "Logged out successfully"
}
```

---

# Admin APIs

## 8. Admin Login

Admin login with email and password.

**Endpoint:** `POST /admin/login`

**Access:** Public

**Request Body:**
```json
{
  "email": "admin@countrydelight.com",
  "password": "admin123"
}
```

**Response:** `200 OK`
```json
{
  "user": {
    "id": "65abc789def012345678901",
    "phone": "9999999999",
    "email": "admin@countrydelight.com",
    "firstName": "Admin",
    "lastName": "User",
    "role": "admin"
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

## 9. Create Delivery Boy

Admin creates a delivery boy account.

**Endpoint:** `POST /admin/delivery-boy`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "phone": "9123456789",
  "email": "delivery@example.com",
  "password": "delivery123",
  "firstName": "Delivery",
  "lastName": "Boy"
}
```

**Response:** `201 Created`
```json
{
  "message": "Delivery boy created successfully",
  "deliveryBoy": {
    "id": "65abc456def789012345678",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy"
  }
}
```

---

## 10. Get All Delivery Boys

Admin gets list of all delivery boys.

**Endpoint:** `GET /admin/delivery-boys`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
[
  {
    "id": "65abc456def789012345678",
    "phone": "9123456789",
    "email": "delivery@example.com",
    "firstName": "Delivery",
    "lastName": "Boy",
    "role": "delivery_boy",
    "isActive": true,
    "isPhoneVerified": true,
    "createdAt": "2025-01-01T00:00:00.000Z"
  }
]
```

---

## 11. Get All Customers

Admin gets list of all customers.

**Endpoint:** `GET /admin/customers`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
[
  {
    "id": "65abc123def456789012345",
    "phone": "9876543210",
    "email": "customer@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer",
    "isActive": true,
    "createdAt": "2025-01-01T00:00:00.000Z"
  }
]
```

---

## 12. Get All Users

Admin gets list of all users.

**Endpoint:** `GET /admin/users`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
[
  {
    "id": "65abc123def456789012345",
    "phone": "9876543210",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "customer",
    "isActive": true
  }
]
```

---

# User Profile APIs

## 13. Get Profile

Get current user's profile.

**Endpoint:** `GET /users/profile`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65abc123def456789012345",
  "phone": "9876543210",
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "customer",
  "isActive": true,
  "isPhoneVerified": true,
  "isEmailVerified": false,
  "address": {
    "street": "123 Main St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001"
  },
  "createdAt": "2025-01-01T00:00:00.000Z",
  "updatedAt": "2025-01-15T00:00:00.000Z"
}
```

---

## 14. Update Profile

Update current user's profile.

**Endpoint:** `PATCH /users/profile`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "newemail@example.com",
  "address": {
    "street": "456 New St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400002"
  }
}
```

**Response:** `200 OK`
```json
{
  "id": "65abc123def456789012345",
  "phone": "9876543210",
  "email": "newemail@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "customer",
  "address": {
    "street": "456 New St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400002"
  }
}
```

---

# Category APIs

## 15. Get All Categories

Get list of all categories.

**Endpoint:** `GET /categories`

**Access:** Public

**Query Parameters:**
- `isActive` (optional): Filter by active status (true/false)

**Example:**
```
GET /categories?isActive=true
```

**Response:** `200 OK`
```json
[
  {
    "id": "65cat123def456789012345",
    "name": "Milk",
    "slug": "milk",
    "description": "Fresh milk and dairy products",
    "image": "https://example.com/milk.jpg",
    "isActive": true,
    "order": 1,
    "createdAt": "2025-01-01T00:00:00.000Z"
  },
  {
    "id": "65cat456def789012345678",
    "name": "Fruits",
    "slug": "fruits",
    "description": "Fresh fruits",
    "isActive": true,
    "order": 2
  }
]
```

---

## 16. Get Category by ID

Get single category details.

**Endpoint:** `GET /categories/:id`

**Access:** Public

**Response:** `200 OK`
```json
{
  "id": "65cat123def456789012345",
  "name": "Milk",
  "slug": "milk",
  "description": "Fresh milk and dairy products",
  "image": "https://example.com/milk.jpg",
  "isActive": true,
  "order": 1,
  "createdAt": "2025-01-01T00:00:00.000Z"
}
```

---

## 17. Create Category

Create a new category.

**Endpoint:** `POST /categories`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "name": "Milk",
  "description": "Fresh milk and dairy products",
  "image": "https://example.com/milk.jpg",
  "isActive": true,
  "order": 1
}
```

**Response:** `201 Created`
```json
{
  "id": "65cat123def456789012345",
  "name": "Milk",
  "slug": "milk",
  "description": "Fresh milk and dairy products",
  "image": "https://example.com/milk.jpg",
  "isActive": true,
  "order": 1
}
```

---

## 18. Update Category

Update existing category.

**Endpoint:** `PATCH /categories/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "name": "Dairy Products",
  "description": "Fresh dairy products",
  "isActive": true
}
```

**Response:** `200 OK`
```json
{
  "id": "65cat123def456789012345",
  "name": "Dairy Products",
  "slug": "dairy-products",
  "description": "Fresh dairy products",
  "isActive": true
}
```

---

## 19. Delete Category

Delete a category.

**Endpoint:** `DELETE /categories/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
{
  "message": "Category deleted successfully"
}
```

---

# Product APIs

## 20. Get All Products

Get list of all products.

**Endpoint:** `GET /products`

**Access:** Public

**Query Parameters:**
- `categoryId` (optional): Filter by category ID
- `isFeatured` (optional): Filter by featured status (true/false)

**Example:**
```
GET /products?categoryId=65cat123def456789012345&isFeatured=true
```

**Response:** `200 OK`
```json
[
  {
    "id": "65prod123def456789012345",
    "name": "Full Cream Milk",
    "slug": "full-cream-milk",
    "description": "Fresh full cream milk delivered daily",
    "category": {
      "id": "65cat123def456789012345",
      "name": "Milk",
      "slug": "milk"
    },
    "price": 65,
    "discountedPrice": 60,
    "unit": "1L",
    "images": ["https://example.com/milk1.jpg"],
    "isAvailable": true,
    "isActive": true,
    "stockQuantity": 100,
    "isFeatured": true,
    "tags": ["dairy", "fresh"],
    "nutritionalInfo": {
      "calories": 150,
      "protein": 8,
      "fat": 8,
      "carbs": 12
    }
  }
]
```

---

## 21. Get Product by ID

Get single product details.

**Endpoint:** `GET /products/:id`

**Access:** Public

**Response:** `200 OK`
```json
{
  "id": "65prod123def456789012345",
  "name": "Full Cream Milk",
  "slug": "full-cream-milk",
  "description": "Fresh full cream milk delivered daily",
  "category": {
    "id": "65cat123def456789012345",
    "name": "Milk"
  },
  "price": 65,
  "discountedPrice": 60,
  "unit": "1L",
  "images": ["https://example.com/milk1.jpg"],
  "isAvailable": true,
  "stockQuantity": 100
}
```

---

## 22. Create Product

Create a new product.

**Endpoint:** `POST /products`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "name": "Full Cream Milk",
  "description": "Fresh full cream milk",
  "category": "65cat123def456789012345",
  "price": 65,
  "discountedPrice": 60,
  "unit": "1L",
  "images": ["https://example.com/milk.jpg"],
  "stockQuantity": 100,
  "tags": ["dairy", "fresh"],
  "isFeatured": true
}
```

**Response:** `201 Created`
```json
{
  "id": "65prod123def456789012345",
  "name": "Full Cream Milk",
  "slug": "full-cream-milk",
  "category": "65cat123def456789012345",
  "price": 65,
  "discountedPrice": 60,
  "unit": "1L",
  "stockQuantity": 100
}
```

---

## 23. Update Product

Update existing product.

**Endpoint:** `PATCH /products/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "price": 70,
  "discountedPrice": 65,
  "stockQuantity": 150,
  "isAvailable": true
}
```

**Response:** `200 OK`
```json
{
  "id": "65prod123def456789012345",
  "name": "Full Cream Milk",
  "price": 70,
  "discountedPrice": 65,
  "stockQuantity": 150,
  "isAvailable": true
}
```

---

## 24. Delete Product

Delete a product.

**Endpoint:** `DELETE /products/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
{
  "message": "Product deleted successfully"
}
```

---

# Subscription Plan APIs

## 25. Get All Subscription Plans

Get list of all subscription plans.

**Endpoint:** `GET /subscriptions/plans`

**Access:** Public

**Query Parameters:**
- `productId` (optional): Filter by product ID

**Example:**
```
GET /subscriptions/plans?productId=65prod123def456789012345
```

**Response:** `200 OK`
```json
[
  {
    "id": "65plan123def456789012345",
    "name": "Daily Milk - 1L",
    "description": "Get 1L milk delivered daily",
    "product": {
      "id": "65prod123def456789012345",
      "name": "Full Cream Milk",
      "unit": "1L"
    },
    "type": "daily",
    "quantity": 1,
    "pricePerUnit": 60,
    "totalPrice": 1800,
    "discountPercentage": 10,
    "duration": 30,
    "isActive": true
  }
]
```

**Subscription Types:**
- `daily` - Every day
- `alternate_days` - Every alternate day
- `weekly` - Once a week
- `custom` - Custom delivery days

---

## 26. Get Subscription Plan by ID

Get single subscription plan details.

**Endpoint:** `GET /subscriptions/plans/:id`

**Access:** Public

**Response:** `200 OK`
```json
{
  "id": "65plan123def456789012345",
  "name": "Daily Milk - 1L",
  "description": "Get 1L milk delivered daily for 30 days",
  "product": {
    "id": "65prod123def456789012345",
    "name": "Full Cream Milk",
    "price": 65,
    "unit": "1L"
  },
  "type": "daily",
  "quantity": 1,
  "pricePerUnit": 60,
  "totalPrice": 1800,
  "discountPercentage": 10,
  "duration": 30,
  "deliveryDays": [],
  "isActive": true
}
```

---

## 27. Create Subscription Plan

Create a new subscription plan.

**Endpoint:** `POST /subscriptions/plans`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "name": "Daily Milk - 1L",
  "description": "Get 1L milk delivered daily",
  "product": "65prod123def456789012345",
  "type": "daily",
  "quantity": 1,
  "pricePerUnit": 60,
  "totalPrice": 1800,
  "discountPercentage": 10,
  "duration": 30
}
```

**Request Body (Custom Delivery Days):**
```json
{
  "name": "Custom Milk Delivery",
  "description": "Milk on selected days",
  "product": "65prod123def456789012345",
  "type": "custom",
  "quantity": 1,
  "pricePerUnit": 60,
  "totalPrice": 720,
  "duration": 30,
  "deliveryDays": [1, 3, 5]
}
```

**Notes:**
- `deliveryDays`: Array of weekday numbers (0=Sunday, 1=Monday, ..., 6=Saturday)

**Response:** `201 Created`
```json
{
  "id": "65plan123def456789012345",
  "name": "Daily Milk - 1L",
  "product": "65prod123def456789012345",
  "type": "daily",
  "quantity": 1,
  "pricePerUnit": 60,
  "totalPrice": 1800,
  "duration": 30
}
```

---

## 28. Update Subscription Plan

Update existing subscription plan.

**Endpoint:** `PATCH /subscriptions/plans/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "pricePerUnit": 55,
  "totalPrice": 1650,
  "discountPercentage": 15,
  "isActive": true
}
```

**Response:** `200 OK`
```json
{
  "id": "65plan123def456789012345",
  "name": "Daily Milk - 1L",
  "pricePerUnit": 55,
  "totalPrice": 1650,
  "discountPercentage": 15,
  "isActive": true
}
```

---

## 29. Delete Subscription Plan

Delete a subscription plan.

**Endpoint:** `DELETE /subscriptions/plans/:id`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Response:** `200 OK`
```json
{
  "message": "Subscription plan deleted successfully"
}
```

---

# User Subscription APIs

## 30. Subscribe to Plan

Create a new subscription.

**Endpoint:** `POST /subscriptions`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "plan": "65plan123def456789012345",
  "deliveryAddress": "65addr123def456789012345",
  "startDate": "2025-01-15"
}
```

**Notes:**
- `startDate` is optional, defaults to today
- `deliveryAddress` must be a valid address ID created by the user

**Response:** `201 Created`
```json
{
  "id": "65subs123def456789012345",
  "user": "65abc123def456789012345",
  "plan": "65plan123def456789012345",
  "deliveryAddress": "65addr123def456789012345",
  "startDate": "2025-01-15T00:00:00.000Z",
  "endDate": "2025-02-14T00:00:00.000Z",
  "status": "active",
  "totalAmount": 1800,
  "isPaid": false,
  "createdAt": "2025-01-14T00:00:00.000Z"
}
```

---

## 31. Get My Subscriptions

Get user's subscriptions.

**Endpoint:** `GET /subscriptions/my-subscriptions`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Query Parameters:**
- `status` (optional): Filter by status (active/paused/cancelled/expired)

**Example:**
```
GET /subscriptions/my-subscriptions?status=active
```

**Response:** `200 OK`
```json
[
  {
    "id": "65subs123def456789012345",
    "plan": {
      "id": "65plan123def456789012345",
      "name": "Daily Milk - 1L",
      "type": "daily",
      "product": {
        "name": "Full Cream Milk",
        "unit": "1L"
      }
    },
    "deliveryAddress": {
      "fullName": "John Doe",
      "phone": "9876543210",
      "addressLine1": "123 Main St",
      "city": "Mumbai"
    },
    "startDate": "2025-01-15T00:00:00.000Z",
    "endDate": "2025-02-14T00:00:00.000Z",
    "status": "active",
    "totalAmount": 1800,
    "isPaid": false
  }
]
```

**Subscription Status:**
- `active` - Currently active
- `paused` - Temporarily paused
- `cancelled` - Cancelled by user
- `expired` - Subscription period ended

---

## 32. Pause Subscription

Temporarily pause a subscription.

**Endpoint:** `PATCH /subscriptions/:id/pause`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "pausedUntil": "2025-02-01"
}
```

**Response:** `200 OK`
```json
{
  "id": "65subs123def456789012345",
  "status": "paused",
  "pausedFrom": "2025-01-20T00:00:00.000Z",
  "pausedUntil": "2025-02-01T00:00:00.000Z"
}
```

**Notes:**
- Can only pause active subscriptions
- Deliveries will not be created during pause period

---

## 33. Resume Subscription

Resume a paused subscription.

**Endpoint:** `PATCH /subscriptions/:id/resume`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65subs123def456789012345",
  "status": "active",
  "pausedFrom": null,
  "pausedUntil": null
}
```

**Notes:**
- Can only resume paused subscriptions

---

## 34. Cancel Subscription

Cancel a subscription.

**Endpoint:** `PATCH /subscriptions/:id/cancel`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "reason": "Moving to a different location"
}
```

**Response:** `200 OK`
```json
{
  "id": "65subs123def456789012345",
  "status": "cancelled",
  "cancelledAt": "2025-01-20T00:00:00.000Z",
  "cancellationReason": "Moving to a different location"
}
```

**Notes:**
- `reason` is optional
- Cannot cancel already delivered subscriptions (depends on business logic)

---

# Address APIs

## 35. Create Address

Create a new delivery address.

**Endpoint:** `POST /addresses`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "fullName": "John Doe",
  "phone": "9876543210",
  "addressLine1": "123 Main Street",
  "addressLine2": "Apartment 4B",
  "city": "Mumbai",
  "state": "Maharashtra",
  "pincode": "400001",
  "landmark": "Near XYZ Mall",
  "type": "home",
  "isDefault": true
}
```

**Notes:**
- `type` can be: home, work, other
- `addressLine2` and `landmark` are optional
- Setting `isDefault` to true will make this the default address

**Response:** `201 Created`
```json
{
  "id": "65addr123def456789012345",
  "user": "65abc123def456789012345",
  "fullName": "John Doe",
  "phone": "9876543210",
  "addressLine1": "123 Main Street",
  "addressLine2": "Apartment 4B",
  "city": "Mumbai",
  "state": "Maharashtra",
  "pincode": "400001",
  "landmark": "Near XYZ Mall",
  "type": "home",
  "isDefault": true
}
```

---

## 36. Get All Addresses

Get user's delivery addresses.

**Endpoint:** `GET /addresses`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
[
  {
    "id": "65addr123def456789012345",
    "fullName": "John Doe",
    "phone": "9876543210",
    "addressLine1": "123 Main Street",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001",
    "type": "home",
    "isDefault": true
  },
  {
    "id": "65addr456def789012345678",
    "fullName": "John Doe",
    "phone": "9876543210",
    "addressLine1": "456 Office Complex",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400002",
    "type": "work",
    "isDefault": false
  }
]
```

**Notes:**
- Addresses are sorted by default status and creation date

---

## 37. Get Address by ID

Get single address details.

**Endpoint:** `GET /addresses/:id`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65addr123def456789012345",
  "fullName": "John Doe",
  "phone": "9876543210",
  "addressLine1": "123 Main Street",
  "addressLine2": "Apartment 4B",
  "city": "Mumbai",
  "state": "Maharashtra",
  "pincode": "400001",
  "landmark": "Near XYZ Mall",
  "type": "home",
  "isDefault": true
}
```

---

## 38. Update Address

Update existing address.

**Endpoint:** `PATCH /addresses/:id`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "addressLine1": "789 New Street",
  "city": "Pune",
  "pincode": "411001",
  "isDefault": true
}
```

**Response:** `200 OK`
```json
{
  "id": "65addr123def456789012345",
  "addressLine1": "789 New Street",
  "city": "Pune",
  "pincode": "411001",
  "isDefault": true
}
```

---

## 39. Delete Address

Delete an address.

**Endpoint:** `DELETE /addresses/:id`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "message": "Address deleted successfully"
}
```

---

# Cart APIs

## 40. Add to Cart

Add item to shopping cart.

**Endpoint:** `POST /cart`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "productId": "65prod123def456789012345",
  "quantity": 2
}
```

**Response:** `200 OK`
```json
{
  "id": "65cart123def456789012345",
  "user": "65abc123def456789012345",
  "items": [
    {
      "product": "65prod123def456789012345",
      "quantity": 2,
      "price": 60
    }
  ],
  "totalAmount": 120
}
```

**Notes:**
- If item already in cart, quantity is added
- Cart is automatically created if doesn't exist

---

## 41. Get Cart

Get user's shopping cart.

**Endpoint:** `GET /cart`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65cart123def456789012345",
  "user": "65abc123def456789012345",
  "items": [
    {
      "product": {
        "id": "65prod123def456789012345",
        "name": "Full Cream Milk",
        "unit": "1L",
        "images": ["https://example.com/milk.jpg"]
      },
      "quantity": 2,
      "price": 60
    },
    {
      "product": {
        "id": "65prod456def789012345678",
        "name": "Bread",
        "unit": "500g"
      },
      "quantity": 1,
      "price": 40
    }
  ],
  "totalAmount": 160,
  "updatedAt": "2025-01-20T00:00:00.000Z"
}
```

**Notes:**
- Returns empty cart if user hasn't added items

---

## 42. Update Item Quantity

Update quantity of item in cart.

**Endpoint:** `PATCH /cart/:productId`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "quantity": 3
}
```

**Response:** `200 OK`
```json
{
  "id": "65cart123def456789012345",
  "items": [
    {
      "product": "65prod123def456789012345",
      "quantity": 3,
      "price": 60
    }
  ],
  "totalAmount": 180
}
```

**Notes:**
- Setting quantity to 0 removes the item

---

## 43. Remove from Cart

Remove item from cart.

**Endpoint:** `DELETE /cart/:productId`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65cart123def456789012345",
  "items": [],
  "totalAmount": 0
}
```

---

## 44. Clear Cart

Clear all items from cart.

**Endpoint:** `DELETE /cart`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65cart123def456789012345",
  "items": [],
  "totalAmount": 0
}
```

---

# Order APIs

## 45. Create Order

Create order from cart.

**Endpoint:** `POST /orders`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "deliveryAddress": "65addr123def456789012345",
  "deliveryDate": "2025-01-22",
  "notes": "Please ring doorbell twice"
}
```

**Notes:**
- `deliveryDate` and `notes` are optional
- Cart must not be empty
- Cart is automatically cleared after order creation

**Response:** `201 Created`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "customer": "65abc123def456789012345",
  "items": [
    {
      "product": "65prod123def456789012345",
      "name": "Full Cream Milk",
      "quantity": 2,
      "price": 60,
      "totalPrice": 120
    }
  ],
  "totalAmount": 120,
  "status": "pending",
  "paymentStatus": "pending",
  "deliveryAddress": "65addr123def456789012345",
  "deliveryDate": "2025-01-22T00:00:00.000Z",
  "notes": "Please ring doorbell twice",
  "createdAt": "2025-01-20T00:00:00.000Z"
}
```

**Order Status:**
- `pending` - Order placed
- `confirmed` - Order confirmed
- `processing` - Being prepared
- `out_for_delivery` - Out for delivery
- `delivered` - Delivered successfully
- `cancelled` - Cancelled

**Payment Status:**
- `pending` - Payment pending
- `paid` - Payment completed
- `failed` - Payment failed
- `refunded` - Amount refunded

---

## 46. Get My Orders

Get user's order history.

**Endpoint:** `GET /orders/my-orders`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Query Parameters:**
- `status` (optional): Filter by order status

**Example:**
```
GET /orders/my-orders?status=delivered
```

**Response:** `200 OK`
```json
[
  {
    "id": "65order123def456789012345",
    "orderNumber": "ORD1737432000ABC12",
    "items": [
      {
        "product": "65prod123def456789012345",
        "name": "Full Cream Milk",
        "quantity": 2,
        "price": 60,
        "totalPrice": 120
      }
    ],
    "totalAmount": 120,
    "status": "delivered",
    "paymentStatus": "paid",
    "deliveryAddress": {
      "fullName": "John Doe",
      "addressLine1": "123 Main St",
      "city": "Mumbai"
    },
    "deliveredAt": "2025-01-22T08:30:00.000Z",
    "createdAt": "2025-01-20T00:00:00.000Z"
  }
]
```

---

## 47. Get Order by ID

Get single order details.

**Endpoint:** `GET /orders/:id`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "items": [
    {
      "product": {
        "id": "65prod123def456789012345",
        "name": "Full Cream Milk",
        "unit": "1L",
        "images": ["https://example.com/milk.jpg"]
      },
      "quantity": 2,
      "price": 60,
      "totalPrice": 120
    }
  ],
  "totalAmount": 120,
  "status": "out_for_delivery",
  "paymentStatus": "paid",
  "deliveryAddress": {
    "fullName": "John Doe",
    "phone": "9876543210",
    "addressLine1": "123 Main St",
    "city": "Mumbai",
    "pincode": "400001"
  },
  "assignedDeliveryBoy": {
    "firstName": "Delivery",
    "lastName": "Boy",
    "phone": "9123456789"
  },
  "deliveryDate": "2025-01-22T00:00:00.000Z",
  "createdAt": "2025-01-20T00:00:00.000Z"
}
```

---

## 48. Cancel Order

Cancel an order.

**Endpoint:** `PATCH /orders/:id/cancel`

**Access:** Protected

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "reason": "Changed my mind"
}
```

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "status": "cancelled",
  "cancelledAt": "2025-01-21T00:00:00.000Z",
  "cancellationReason": "Changed my mind"
}
```

**Notes:**
- Cannot cancel delivered orders
- `reason` is optional

---

## 49. Get All Orders (Admin)

Admin gets all orders.

**Endpoint:** `GET /orders`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Query Parameters:**
- `status` (optional): Filter by order status

**Example:**
```
GET /orders?status=pending
```

**Response:** `200 OK`
```json
[
  {
    "id": "65order123def456789012345",
    "orderNumber": "ORD1737432000ABC12",
    "customer": {
      "firstName": "John",
      "lastName": "Doe",
      "phone": "9876543210",
      "email": "customer@example.com"
    },
    "items": [
      {
        "product": "65prod123def456789012345",
        "name": "Full Cream Milk",
        "quantity": 2,
        "price": 60,
        "totalPrice": 120
      }
    ],
    "totalAmount": 120,
    "status": "pending",
    "paymentStatus": "pending",
    "deliveryAddress": {
      "fullName": "John Doe",
      "addressLine1": "123 Main St",
      "city": "Mumbai"
    },
    "createdAt": "2025-01-20T00:00:00.000Z"
  }
]
```

---

## 50. Update Order Status (Admin)

Admin updates order status.

**Endpoint:** `PATCH /orders/:id/status`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "status": "confirmed"
}
```

**Valid Status Values:**
- pending
- confirmed
- processing
- out_for_delivery
- delivered
- cancelled

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "status": "confirmed"
}
```

---

## 51. Assign Delivery Boy (Admin)

Admin assigns delivery boy to order.

**Endpoint:** `PATCH /orders/:id/assign`

**Access:** Admin Only

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request Body:**
```json
{
  "deliveryBoyId": "65dboy123def456789012345"
}
```

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "status": "processing",
  "assignedDeliveryBoy": "65dboy123def456789012345"
}
```

**Notes:**
- Order status automatically changes to "processing"

---

# Delivery APIs

## 52. Get My Deliveries

Delivery boy gets assigned deliveries.

**Endpoint:** `GET /delivery/my-deliveries`

**Access:** Delivery Boy Only

**Headers:**
```
Authorization: Bearer <delivery_boy_access_token>
```

**Query Parameters:**
- `status` (optional): Filter by order status

**Example:**
```
GET /delivery/my-deliveries?status=out_for_delivery
```

**Response:** `200 OK`
```json
[
  {
    "id": "65order123def456789012345",
    "orderNumber": "ORD1737432000ABC12",
    "customer": {
      "firstName": "John",
      "lastName": "Doe",
      "phone": "9876543210"
    },
    "deliveryAddress": {
      "fullName": "John Doe",
      "phone": "9876543210",
      "addressLine1": "123 Main St",
      "city": "Mumbai",
      "pincode": "400001",
      "landmark": "Near XYZ Mall"
    },
    "items": [
      {
        "product": {
          "name": "Full Cream Milk",
          "unit": "1L"
        },
        "quantity": 2
      }
    ],
    "totalAmount": 120,
    "status": "out_for_delivery",
    "deliveryDate": "2025-01-22T00:00:00.000Z",
    "notes": "Please ring doorbell twice"
  }
]
```

---

## 53. Get Delivery by ID

Delivery boy gets single delivery details.

**Endpoint:** `GET /delivery/my-deliveries/:id`

**Access:** Delivery Boy Only

**Headers:**
```
Authorization: Bearer <delivery_boy_access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "customer": {
    "firstName": "John",
    "lastName": "Doe",
    "phone": "9876543210"
  },
  "deliveryAddress": {
    "fullName": "John Doe",
    "phone": "9876543210",
    "addressLine1": "123 Main St",
    "addressLine2": "Apartment 4B",
    "city": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001",
    "landmark": "Near XYZ Mall"
  },
  "items": [
    {
      "product": {
        "id": "65prod123def456789012345",
        "name": "Full Cream Milk",
        "unit": "1L",
        "images": ["https://example.com/milk.jpg"]
      },
      "quantity": 2,
      "price": 60,
      "totalPrice": 120
    }
  ],
  "totalAmount": 120,
  "status": "out_for_delivery",
  "paymentStatus": "paid",
  "deliveryDate": "2025-01-22T00:00:00.000Z",
  "notes": "Please ring doorbell twice"
}
```

---

## 54. Update Delivery Status

Delivery boy updates delivery status.

**Endpoint:** `PATCH /delivery/:id/status`

**Access:** Delivery Boy Only

**Headers:**
```
Authorization: Bearer <delivery_boy_access_token>
```

**Request Body:**
```json
{
  "status": "out_for_delivery"
}
```

**Valid Status Values:**
- out_for_delivery
- delivered

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "status": "out_for_delivery"
}
```

---

## 55. Mark as Delivered

Delivery boy marks order as delivered.

**Endpoint:** `PATCH /delivery/:id/deliver`

**Access:** Delivery Boy Only

**Headers:**
```
Authorization: Bearer <delivery_boy_access_token>
```

**Response:** `200 OK`
```json
{
  "id": "65order123def456789012345",
  "orderNumber": "ORD1737432000ABC12",
  "status": "delivered",
  "deliveredAt": "2025-01-22T08:30:00.000Z"
}
```

---

## 56. Get Delivery History

Delivery boy gets completed deliveries.

**Endpoint:** `GET /delivery/history`

**Access:** Delivery Boy Only

**Headers:**
```
Authorization: Bearer <delivery_boy_access_token>
```

**Response:** `200 OK`
```json
[
  {
    "id": "65order123def456789012345",
    "orderNumber": "ORD1737432000ABC12",
    "customer": {
      "firstName": "John",
      "lastName": "Doe",
      "phone": "9876543210"
    },
    "deliveryAddress": {
      "fullName": "John Doe",
      "addressLine1": "123 Main St",
      "city": "Mumbai"
    },
    "totalAmount": 120,
    "status": "delivered",
    "deliveredAt": "2025-01-22T08:30:00.000Z"
  }
]
```

---

# Error Responses

## Standard Error Format

All errors follow this format:

```json
{
  "statusCode": 400,
  "message": "Error message here",
  "error": "Bad Request"
}
```

## Validation Error Format

```json
{
  "statusCode": 400,
  "message": [
    "phone must be a valid 10-digit Indian mobile number",
    "firstName should not be empty"
  ],
  "error": "Bad Request"
}
```

## Common Errors

### 400 Bad Request
```json
{
  "statusCode": 400,
  "message": "Cart is empty",
  "error": "Bad Request"
}
```

### 401 Unauthorized
```json
{
  "statusCode": 401,
  "message": "Invalid or expired token",
  "error": "Unauthorized"
}
```

### 403 Forbidden
```json
{
  "statusCode": 403,
  "message": "Insufficient permissions",
  "error": "Forbidden"
}
```

### 404 Not Found
```json
{
  "statusCode": 404,
  "message": "Product not found",
  "error": "Not Found"
}
```

### 409 Conflict
```json
{
  "statusCode": 409,
  "message": "User with this phone already exists",
  "error": "Conflict"
}
```

### 500 Internal Server Error
```json
{
  "statusCode": 500,
  "message": "Internal server error",
  "error": "Internal Server Error"
}
```

---

# Status Codes

## HTTP Status Codes Used

- **200 OK** - Request successful
- **201 Created** - Resource created successfully
- **400 Bad Request** - Invalid request data
- **401 Unauthorized** - Authentication required or failed
- **403 Forbidden** - Insufficient permissions
- **404 Not Found** - Resource not found
- **409 Conflict** - Resource conflict (duplicate)
- **500 Internal Server Error** - Server error

---

# Rate Limiting

Currently not implemented. Will be added in production:
- 100 requests per 15 minutes per IP
- 1000 requests per hour per authenticated user

---

# Pagination

Currently not implemented. All list endpoints return complete data.

Future implementation will include:
```
GET /products?page=1&limit=20
```

Response:
```json
{
  "data": [...],
  "page": 1,
  "limit": 20,
  "total": 150,
  "totalPages": 8
}
```

---

# Webhooks

Not currently implemented. Future webhook events:
- `order.created`
- `order.delivered`
- `subscription.created`
- `subscription.cancelled`
- `payment.completed`

---

# API Versioning

Current version: v1

Base URL includes version: `/api/v1`

Future versions will be: `/api/v2`, `/api/v3`, etc.

---

# Support

- **Swagger Documentation**: http://localhost:3000/api/docs
- **Issues**: Report bugs in the repository
- **Email**: support@countrydelight.com (example)

---

**Last Updated**: January 2025
**API Version**: 1.0
**Total Endpoints**: 56
