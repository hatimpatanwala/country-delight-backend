export enum UserRole {
  ADMIN = 'admin',
  CUSTOMER = 'customer',
  DELIVERY_BOY = 'delivery_boy',
}
