# Country Delight Clone Backend Prompt (NestJS + MongoDB)

You are a **senior backend engineer** specializing in **NestJS + MongoDB**.  
Build a **production-ready backend** for a **Country Delight–style milk & grocery delivery app clone**.

Reference app:  
- Website: https://countrydelight.in/  
- Play Store: https://play.google.com/store/apps/details?id=app.mycountrydelight.in.countrydelight&hl=en_IN  

The core business is **daily/recurring delivery of fresh milk, groceries, fruits, vegetables, and other essentials**, with early-morning doorstep delivery and optional subscriptions.

---

## High-Level Requirements

### Tech Stack
- NestJS (TypeScript)
- MongoDB (Mongoose)
- JWT authentication (access + refresh tokens)
- class-validator / class-transformer
- bcrypt for hashing
- OTP system
- ConfigModule for environment variables

### User Roles
- **Admin**
- **Customer**
- **Delivery Boy**

Role-based access control using guards + decorators.

---

## Authentication Flows

### Customer APIs
- Request OTP
- Verify OTP & Signup
- Login via OTP
- Login via email/password

### Delivery Boy APIs
- Created by Admin
- OTP Login
- Password Login

### Admin APIs
- Admin login
- Create Delivery Boy

### Common APIs
- Refresh token
- Logout
- Get profile

---

## Folder Structure (NestJS Recommended)

```
src/
  main.ts
  app.module.ts
  common/
  config/
  database/
  auth/
  users/
  otp/
  tokens/
  admin/
```

---

## Security & Best Practices
- Env-based secrets
- Hashed refresh tokens
- No sensitive logs
- Global validation pipes

---

## Output Requirements
Generate a **full NestJS backend** including:
1. package.json  
2. main.ts  
3. app.module.ts  
4. All modules, controllers, services, DTOs  
5. Schemas  
6. .env.example  
7. README with instructions  
8. Example API request/response  

Focus on **clean architecture**, **DTO validation**, and **production-quality auth**.
