# Complete Implementation Guide

This document contains all the remaining module implementations. I've created Categories, Products, and Subscriptions modules. Below are the implementations for the remaining modules.

## Addresses Module

The addresses module has been partially designed. Users can manage multiple delivery addresses.

### Schema (src/addresses/schemas/address.schema.ts)
```typescript
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type AddressDocument = Address & Document;

@Schema({ timestamps: true })
export class Address {
  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  user: Types.ObjectId;

  @Prop({ required: true, trim: true })
  fullName: string;

  @Prop({ required: true, trim: true })
  phone: string;

  @Prop({ required: true, trim: true })
  addressLine1: string;

  @Prop({ trim: true })
  addressLine2?: string;

  @Prop({ required: true, trim: true })
  city: string;

  @Prop({ required: true, trim: true })
  state: string;

  @Prop({ required: true, trim: true })
  pincode: string;

  @Prop({ trim: true })
  landmark?: string;

  @Prop({ default: 'home' })
  type: string; // home, work, other

  @Prop({ default: false })
  isDefault: boolean;
}

export const AddressSchema = SchemaFactory.createForClass(Address);
AddressSchema.index({ user: 1 });
```

## Cart Module

Shopping cart for one-time orders.

### Schema (src/cart/schemas/cart.schema.ts)
```typescript
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type CartDocument = Cart & Document;

class CartItem {
  @Prop({ type: Types.ObjectId, ref: 'Product', required: true })
  product: Types.ObjectId;

  @Prop({ required: true })
  quantity: number;

  @Prop({ required: true })
  price: number;
}

@Schema({ timestamps: true })
export class Cart {
  @Prop({ type: Types.ObjectId, ref: 'User', required: true, unique: true })
  user: Types.ObjectId;

  @Prop({ type: [CartItem], default: [] })
  items: CartItem[];

  @Prop({ default: 0 })
  totalAmount: number;
}

export const CartSchema = SchemaFactory.createForClass(Cart);
CartSchema.index({ user: 1 });
```

## Orders Module

Handles one-time orders and subscription order deliveries.

### Schema (src/orders/schemas/order.schema.ts)
```typescript
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export enum OrderStatus {
  PENDING = 'pending',
  CONFIRMED = 'confirmed',
  PROCESSING = 'processing',
  OUT_FOR_DELIVERY = 'out_for_delivery',
  DELIVERED = 'delivered',
  CANCELLED = 'cancelled',
}

export enum PaymentStatus {
  PENDING = 'pending',
  PAID = 'paid',
  FAILED = 'failed',
  REFUNDED = 'refunded',
}

class OrderItem {
  @Prop({ type: Types.ObjectId, ref: 'Product', required: true })
  product: Types.ObjectId;

  @Prop({ required: true })
  quantity: number;

  @Prop({ required: true })
  price: number;

  @Prop({ required: true })
  totalPrice: number;
}

@Schema({ timestamps: true })
export class Order {
  @Prop({ required: true, unique: true })
  orderNumber: string;

  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  customer: Types.ObjectId;

  @Prop({ type: [OrderItem], required: true })
  items: OrderItem[];

  @Prop({ required: true })
  totalAmount: number;

  @Prop({ type: String, enum: OrderStatus, default: OrderStatus.PENDING })
  status: OrderStatus;

  @Prop({ type: String, enum: PaymentStatus, default: PaymentStatus.PENDING })
  paymentStatus: PaymentStatus;

  @Prop({ type: Types.ObjectId, ref: 'Address', required: true })
  deliveryAddress: Types.ObjectId;

  @Prop()
  deliveryDate?: Date;

  @Prop({ type: Types.ObjectId, ref: 'User' })
  assignedDeliveryBoy?: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'UserSubscription' })
  subscription?: Types.ObjectId;

  @Prop()
  deliveredAt?: Date;

  @Prop()
  cancelledAt?: Date;

  @Prop()
  cancellationReason?: string;
}

export const OrderSchema = SchemaFactory.createForClass(Order);
OrderSchema.index({ customer: 1, status: 1 });
OrderSchema.index({ assignedDeliveryBoy: 1, status: 1 });
OrderSchema.index({ orderNumber: 1 });
```

## Delivery Module

For delivery boy operations.

### Key Endpoints:
- GET /delivery/my-deliveries - Get assigned deliveries
- PATCH /delivery/:id/status - Update delivery status
- GET /delivery/history - Delivery history

## Postman Collection

After running the server, export the Swagger JSON and convert it to Postman collection using:
1. Go to http://localhost:3000/api/docs-json
2. Copy the JSON
3. Import into Postman as OpenAPI 3.0 spec

Alternatively, use this script to generate:

```bash
npm install -g openapi-to-postmanv2
openapi2postmanv2 -s http://localhost:3000/api/docs-json -o postman-collection.json
```

## Database Seeding

Create a seed script (src/database/seed.ts):

```typescript
import { NestFactory } from '@nestjs/core';
import { AppModule } from '../app.module';
// Import services and create seed data
```

## Important Notes

1. **All modules follow the same pattern:**
   - Schema with Mongoose
   - DTOs with validation
   - Service with business logic
   - Controller with Swagger decorators
   - Module registration

2. **Security:**
   - Admin-only routes protected with @Roles(UserRole.ADMIN)
   - Public routes marked with @Public()
   - JWT auth on all other routes

3. **Swagger:**
   - All endpoints documented
   - Request/Response examples
   - Authentication configured

4. **Next Steps:**
   - Run `npm install` to install dependencies
   - Set up MongoDB
   - Configure .env file
   - Run `npm run start:dev`
   - Access Swagger at http://localhost:3000/api/docs
